AHTTAK — static frontend for cPanel
====================================

WHAT TO UPLOAD
--------------
Upload EVERYTHING in this folder (including the "assets" folder, index.html,
robots.txt, sitemap.xml, vite.svg if present) into your cPanel "public_html"
(or the document root for your domain). Use "Extract" if you uploaded this
zip, or copy files so index.html sits at the site root.

BACKEND / API
-------------
This app calls the API at the SAME hostname under path "/api" (see browser
network tab). So you must either:

  • Point your domain’s "/api" to your Django server (reverse proxy), or
  • Host the API on the same domain in a way your host supports.

The Django ".env" file belongs ONLY on the server that runs Django — not in
public_html. Do not put database or SMTP secrets inside the web root.

FRONTEND ENV (Vite)
-------------------
A plain file named ".env" on cPanel does NOT change this site after build.
Only variables starting with VITE_ are used, and only when you run
"npm run build" on your computer.

See ".env.production.example" in this zip. To use a custom public URL for SEO
meta tags, copy it to frontend/.env.production before building, then rebuild.

Default production site URL in the build is already https://ahttak.or.ke

OPTIONAL IMAGES
---------------
If you use public-folder hero images, add ahttak1.jpeg … ahttak9.jpeg next to
index.html (same folder) on the server.
